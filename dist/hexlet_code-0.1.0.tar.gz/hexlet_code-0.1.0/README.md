### Hexlet tests and linter status:
[![Actions Status](https://github.com/artxnv/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/artxnv/python-project-50/actions)

[![Test Coverage](https://codeclimate.com/github/artxnv/python-project-50/badges/coverage.svg)](https://codeclimate.com/github/artxnv/python-project-50/coverage)

