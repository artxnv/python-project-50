### Hexlet tests and linter status:
[![Actions Status](https://github.com/artxnv/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/artxnv/python-project-50/actions)

[![Test Coverage](https://codeclimate.com/github/artxnv/python-project-50/badges/coverage.svg)](https://codeclimate.com/github/artxnv/python-project-50/coverage)

[![Maintainability](https://api.codeclimate.com/v1/badges/5bdc7500247f242dfa70/maintainability)](https://codeclimate.com/github/artxnv/python-project-50/maintainability)

[![Python CI](https://github.com/artxnv/python-project-50/actions/workflows/python-ci.yml/badge.svg)](https://github.com/artxnv/python-project-50/actions/workflows/python-ci.yml)