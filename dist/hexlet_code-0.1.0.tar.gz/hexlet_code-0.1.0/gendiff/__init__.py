from .scripts.generate_diff import generate_diff
